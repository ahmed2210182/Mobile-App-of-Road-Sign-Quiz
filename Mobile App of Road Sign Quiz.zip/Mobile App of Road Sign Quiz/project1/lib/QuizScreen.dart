import 'package:flutter/material.dart';
import 'ResultScreen.dart';

class QuizScreen extends StatefulWidget {
  const QuizScreen({super.key});

  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int questionIndex = 0;
  int score = 0;

  final questions = [
    {
      'image': 'assets/images/stop_sign.png',
      'question': 'What does this sign mean?',
      'answers': ['Stop', 'Yield', 'Speed Limit'],
      'correct': 'Stop',
    },
    {
      'image': 'assets/images/yield_sign.png',
      'question': 'What does this sign mean?',
      'answers': ['Give way', 'Stop', 'No Parking'],
      'correct': 'Give way',
    },
    {
      'image': 'assets/images/speed_limit_50.png',
      'question': 'What does this sign indicate?',
      'answers': ['Speed limit of 50 km/h', 'Minimum speed 50 km/h', 'No speed limit'],
      'correct': 'Speed limit of 50 km/h',
    },
    {
      'image': 'assets/images/no_parking.png',
      'question': 'What does this sign mean?',
      'answers': ['No Parking', 'No Entry', 'Road Closed'],
      'correct': 'No Parking',
    },
    {
      'image': 'assets/images/pedestrian_crossing.png',
      'question': 'What does this sign represent?',
      'answers': ['Pedestrian Crossing', 'School Zone', 'Hospital Zone'],
      'correct': 'Pedestrian Crossing',
    },
    {
      'image': 'assets/images/railway_crossing.png',
      'question': 'What does this sign indicate?',
      'answers': ['Railway Crossing', 'Bridge Ahead', 'Tunnel'],
      'correct': 'Railway Crossing',
    },
    {
      'image': 'assets/images/school_zone.png',
      'question': 'What does this sign mean?',
      'answers': ['School Zone', 'Hospital Zone', 'Playground Ahead'],
      'correct': 'School Zone',
    },
    {
      'image': 'assets/images/no_entry.png',
      'question': 'What does this sign represent?',
      'answers': ['No Entry', 'One-Way', 'Stop'],
      'correct': 'No Entry',
    },
    {
      'image': 'assets/images/road_work.png',
      'question': 'What does this sign indicate?',
      'answers': ['Road Work Ahead', 'Traffic Jam', 'Detour'],
      'correct': 'Road Work Ahead',
    },
    {
      'image': 'assets/images/roundabout.png',
      'question': 'What does this sign mean?',
      'answers': ['Roundabout Ahead', 'U-Turn', 'Yield'],
      'correct': 'Roundabout Ahead',
    },
    {
      'image': 'assets/images/slippery_road.png',
      'question': 'What does this sign indicate?',
      'answers': ['Slippery Road Ahead', 'Road Under Construction', 'Pedestrian Crossing'],
      'correct': 'Slippery Road Ahead',
    },

    {
      'image': 'assets/images/traffic_light_ahead.png',
      'question': 'What does this sign mean?',
      'answers': ['Traffic Lights Ahead', 'Pedestrian Crossing', 'Roundabout'],
      'correct': 'Traffic Lights Ahead',
    },
    {
      'image': 'assets/images/animal_crossing.png',
      'question': 'What does this sign indicate?',
      'answers': ['Animal Crossing', 'Farm Ahead', 'Fallen Rocks'],
      'correct': 'Animal Crossing',
    },
    {
      'image': 'assets/images/speed_bump.png',
      'question': 'What does this sign indicate?',
      'answers': ['Speed Bump Ahead', 'Road Works', 'Curve Ahead'],
      'correct': 'Speed Bump Ahead',
    },
    {
      'image': 'assets/images/fog_warning.png',
      'question': 'What does this sign indicate?',
      'answers': ['Fog Warning', 'Slippery Road', 'Ice on Road'],
      'correct': 'Fog Warning',
    },
  ];
  @override
  void initState() {
    super.initState();
    shuffleQuestionsAndAnswers();
  }

  void shuffleQuestionsAndAnswers() {
    // Shuffle questions and their answers
    questions.shuffle();
    for (var question in questions) {
      List<String> answers = question['answers'] as List<String>;
      answers.shuffle();
    }
  }

  void answerQuestion(String answer) {
    if (answer == questions[questionIndex]['correct']) {
      score++;
    }

    setState(() {
      questionIndex++;
    });

    if (questionIndex >= questions.length) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => ResultScreen(score: score)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Road Sign Quiz')),
      body: questionIndex < questions.length
          ? Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset(
              questions[questionIndex]['image'] as String,
              height: 200,
              errorBuilder: (context, error, stackTrace) {
                return const Text('Image not found');
              },
            ),
            const SizedBox(height: 20),
            Text(
              questions[questionIndex]['question'] as String,
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ...(questions[questionIndex]['answers'] as List<String>).map(
                  (answer) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5.0),
                  child: ElevatedButton(
                    onPressed: () => answerQuestion(answer),
                    child: Text(answer),
                  ),
                );
              },
            ),
          ],
        ),
      )
          : const Center(child: CircularProgressIndicator()),
    );
  }
}
