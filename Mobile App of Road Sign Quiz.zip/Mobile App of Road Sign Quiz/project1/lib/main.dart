import 'package:flutter/material.dart';
import 'WelcomeScreen.dart';

void main() {
  runApp(const RoadSignQuizApp());
}

class RoadSignQuizApp extends StatelessWidget {
  const RoadSignQuizApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Road Sign Quiz',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const WelcomeScreen(),
    );
  }
}
